package ylsoft.com.identification_card_identify;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.widget.Toast;

import com.baidu.ocr.sdk.OCR;
import com.baidu.ocr.sdk.OnResultListener;
import com.baidu.ocr.sdk.exception.OCRError;
import com.baidu.ocr.sdk.model.AccessToken;
import com.baidu.ocr.sdk.model.IDCardParams;
import com.baidu.ocr.sdk.model.IDCardResult;
import com.baidu.ocr.ui.camera.CameraActivity;

import java.io.File;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry.Registrar;


/** IdentificationCardIdentifyPlugin */
public class IdentificationCardIdentifyPlugin implements MethodCallHandler,PreferenceManager.OnActivityResultListener {

  private boolean hasGotToken = false;
  private static final int REQUEST_CODE_PICK_IMAGE_FRONT = 201;
  private static final int REQUEST_CODE_PICK_IMAGE_BACK = 202;
  private static final int REQUEST_CODE_CAMERA = 102;
  private Activity mContext;
  private AlertDialog.Builder alertDialog;
  /** Plugin registration. */
  public static void registerWith(Registrar registrar) {
    final MethodChannel channel = new MethodChannel(registrar.messenger(), "identification_card_identify");
    channel.setMethodCallHandler(new IdentificationCardIdentifyPlugin(registrar.activity()));
  }

  public IdentificationCardIdentifyPlugin(Activity mContext){
    this.mContext = mContext;
  }

  @Override
  public void onMethodCall(MethodCall call, Result result) {
    if (call.method.equals("getPlatformVersion")) {
      result.success("Android " + android.os.Build.VERSION.RELEASE);
    } else if(call.method.equals("Initialize")){
      initAccessTokenWithAkSk(call.argument("AK").toString(),call.argument("SK").toString());
    }else if(call.method.equals("IDCard_identify")){
      if(call.hasArgument("CardTypeIdCardFont")){
        if(checkTokenStatus()){
          getCardFront();
        }
      }else if(call.hasArgument("CardTypeIdCardBack")){
        if(checkTokenStatus()){
          getCardBack();
        }
      }
    }else {
      result.notImplemented();
    }
  }

  /**
   * 用明文ak，sk初始化
   */
  private void initAccessTokenWithAkSk(String ak,String sk) {
    OCR.getInstance(mContext).initAccessTokenWithAkSk(new OnResultListener<AccessToken>() {
      @Override
      public void onResult(AccessToken result) {
        String token = result.getAccessToken();
        hasGotToken = true;
      }

      @Override
      public void onError(OCRError error) {
        error.printStackTrace();
        alertText("AK，SK方式获取token失败", error.getMessage());
      }
    }, mContext.getApplicationContext(),  ak, sk);
  }

  private boolean checkTokenStatus() {
    if (!hasGotToken) {
      Toast.makeText(mContext.getApplicationContext(), "token还未成功获取", Toast.LENGTH_LONG).show();
    }
    return hasGotToken;
  }
  // 身份证正面扫描
  private void getCardFront(){
    Intent intent = new Intent(mContext, CameraActivity.class);
    intent.putExtra(CameraActivity.KEY_OUTPUT_FILE_PATH,
            FileUtil.getSaveFile(mContext).getAbsolutePath());
    intent.putExtra(CameraActivity.KEY_NATIVE_ENABLE,
            true);
    // KEY_NATIVE_MANUAL设置了之后CameraActivity中不再自动初始化和释放模型
    // 请手动使用CameraNativeHelper初始化和释放模型
    // 推荐这样做，可以避免一些activity切换导致的不必要的异常
    intent.putExtra(CameraActivity.KEY_NATIVE_MANUAL,
            true);
    intent.putExtra(CameraActivity.KEY_CONTENT_TYPE, CameraActivity.CONTENT_TYPE_ID_CARD_FRONT);
    mContext.startActivityForResult(intent, REQUEST_CODE_CAMERA);
  }
  // 身份证反面扫描
  private void getCardBack(){
    Intent intent = new Intent(mContext, CameraActivity.class);
    intent.putExtra(CameraActivity.KEY_OUTPUT_FILE_PATH,
            FileUtil.getSaveFile(mContext).getAbsolutePath());
    intent.putExtra(CameraActivity.KEY_NATIVE_ENABLE,
            true);
    // KEY_NATIVE_MANUAL设置了之后CameraActivity中不再自动初始化和释放模型
    // 请手动使用CameraNativeHelper初始化和释放模型
    // 推荐这样做，可以避免一些activity切换导致的不必要的异常
    intent.putExtra(CameraActivity.KEY_NATIVE_MANUAL,
            true);
    intent.putExtra(CameraActivity.KEY_CONTENT_TYPE, CameraActivity.CONTENT_TYPE_ID_CARD_BACK);
    mContext.startActivityForResult(intent, REQUEST_CODE_CAMERA);
  }

  @Override
  public boolean onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == REQUEST_CODE_PICK_IMAGE_FRONT && resultCode == Activity.RESULT_OK) {
      Uri uri = data.getData();
      String filePath = getRealPathFromURI(uri);
      recIDCard(IDCardParams.ID_CARD_SIDE_FRONT, filePath);
    }

    if (requestCode == REQUEST_CODE_PICK_IMAGE_BACK && resultCode == Activity.RESULT_OK) {
      Uri uri = data.getData();
      String filePath = getRealPathFromURI(uri);
      recIDCard(IDCardParams.ID_CARD_SIDE_BACK, filePath);
    }

    if (requestCode == REQUEST_CODE_CAMERA && resultCode == Activity.RESULT_OK) {
      if (data != null) {
        String contentType = data.getStringExtra(CameraActivity.KEY_CONTENT_TYPE);
        String filePath = FileUtil.getSaveFile(mContext.getApplicationContext()).getAbsolutePath();
        if (!TextUtils.isEmpty(contentType)) {
          if (CameraActivity.CONTENT_TYPE_ID_CARD_FRONT.equals(contentType)) {
            recIDCard(IDCardParams.ID_CARD_SIDE_FRONT, filePath);
          } else if (CameraActivity.CONTENT_TYPE_ID_CARD_BACK.equals(contentType)) {
            recIDCard(IDCardParams.ID_CARD_SIDE_BACK, filePath);
          }
        }
      }
    }
    return false;
  }

  private void recIDCard(String idCardSide, String filePath) {
    IDCardParams param = new IDCardParams();
    param.setImageFile(new File(filePath));
    // 设置身份证正反面
    param.setIdCardSide(idCardSide);
    // 设置方向检测
    param.setDetectDirection(true);
    // 设置图像参数压缩质量0-100, 越大图像质量越好但是请求时间越长。 不设置则默认值为20
    param.setImageQuality(20);

    OCR.getInstance(mContext).recognizeIDCard(param, new OnResultListener<IDCardResult>() {
      @Override
      public void onResult(IDCardResult result) {
        if (result != null) {
          alertText("", result.toString());
        }
      }

      @Override
      public void onError(OCRError error) {
        alertText("", error.getMessage());
      }
    });
  }

  private String getRealPathFromURI(Uri contentURI) {
    String result;
    Cursor cursor = mContext.getContentResolver().query(contentURI, null, null, null, null);
    if (cursor == null) { // Source is Dropbox or other similar local file path
      result = contentURI.getPath();
    } else {
      cursor.moveToFirst();
      int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
      result = cursor.getString(idx);
      cursor.close();
    }
    return result;
  }

  private void alertText(final String title, final String message) {
    if(alertDialog == null){
      alertDialog = new AlertDialog.Builder(mContext);
    }
    mContext.runOnUiThread(new Runnable() {
      @Override
      public void run() {
        alertDialog.setTitle(title)
                .setMessage(message)
                .setPositiveButton("确定", null)
                .show();
      }
    });
  }

}
