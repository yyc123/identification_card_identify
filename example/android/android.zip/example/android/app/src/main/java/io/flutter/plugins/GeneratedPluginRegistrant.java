package io.flutter.plugins;

import io.flutter.plugin.common.PluginRegistry;
import ylsoft.com.identification_card_identify.IdentificationCardIdentifyPlugin;

/**
 * Generated file. Do not edit.
 */
public final class GeneratedPluginRegistrant {
  public static void registerWith(PluginRegistry registry) {
    if (alreadyRegisteredWith(registry)) {
      return;
    }
    IdentificationCardIdentifyPlugin.registerWith(registry.registrarFor("ylsoft.com.identification_card_identify.IdentificationCardIdentifyPlugin"));
  }

  private static boolean alreadyRegisteredWith(PluginRegistry registry) {
    final String key = GeneratedPluginRegistrant.class.getCanonicalName();
    if (registry.hasPlugin(key)) {
      return true;
    }
    registry.registrarFor(key);
    return false;
  }
}
